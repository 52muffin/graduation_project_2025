from django.urls import path
from .views import receive_article
from .views import analyze_article
urlpatterns = [
    path('receive/', receive_article),
    path('analyze/', analyze_article, name='analyze_article'),
]
