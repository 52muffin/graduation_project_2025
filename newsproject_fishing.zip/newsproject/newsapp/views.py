from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import torch
from transformers import BertModel, BertTokenizer, BertConfig

# Config와 모델 초기화
config = BertConfig.from_pretrained("C:/trained_fishing_model")
model = BertModel(config)

# 특정 모델 가중치 로드
# state_dict = torch.load("c:/model/trained_model_final.pt", map_location=torch.device('cpu'))
# model.load_state_dict(state_dict)

# 토크나이저 로드
tokenizer = BertTokenizer.from_pretrained("C:/trained_fishing_model")

model.eval()  # 평가 모드로 설정

@csrf_exempt
def receive_article(request):
    """ 기사 데이터를 받아서 분석 후 결과 반환 """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print("✅ 받은 데이터:", data)  # 데이터 확인 로그

            article_text = data.get("content", "")

            if not article_text:
                print("⚠️ 기사 내용이 없습니다!")
                return JsonResponse({'error': '기사 내용이 없음'}, status=400)

            print("🚀 분석 함수 호출 시작!")
            result = analyze_article(article_text)  # 분석 수행

            print("🔹 분석 결과:", result)
            return JsonResponse(result)

        except Exception as e:
            print("❌ 에러 발생:", e)
            return JsonResponse({'error': str(e)}, status=400)
    else:
        return JsonResponse({'error': 'POST만 허용됨'}, status=405)

def analyze_article(article_text):
    """ 기사 내용을 모델을 통해 분석 후 클래스 예측 """
    try:
        print("🟢 기사 분석 시작!")  # 분석 시작 로그

        # 입력 텍스트 토큰화
        encoded_input = tokenizer(
            article_text,
            return_tensors="pt",
            padding="max_length",
            truncation=True,
            max_length=128
        )

        print("🔹 토큰화 완료:", encoded_input)  # 토큰화 확인

        # 모델 추론 수행
        with torch.no_grad():
            outputs = model(**encoded_input)
            logits = outputs.last_hidden_state[:, 0, :]
            
            # 🔍 logits 크기 확인
            print("📏 Logits shape:", logits.shape)  # 형식이 맞는지 확인
            
            predicted_class = torch.argmax(logits, dim=-1).item()

        # 숫자 클래스 값을 문자로 변환
        class_map = {
            0: "낚시성 기사",
            1: "비낚시성 기사"
        }
        class_label = class_map.get(predicted_class, "알 수 없는 클래스")

        print(f"✅ 예측된 클래스: {class_label}")  # 결과 확인

        return {
            "predicted_class": predicted_class,
            "class_label": class_label,
            "message": "기사 분석 완료"
        }

    except Exception as e:
        print("❌ 분석 중 오류 발생:", e)  # 에러 출력
        return {"error": str(e)}